import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Bootsnip1Component } from './bootsnip1/bootsnip1.component';
import { CategoryComponent } from './category/category.component';
import { ProdviewComponent } from './prodview/prodview.component';
import { ProdListComponent } from './prod-list/prod-list.component';
import { AboutComponent } from './about/about.component';
import { ProdCreateComponent } from './prod-create/prod-create.component';
import { ProdListDBComponent } from './prod-list-db/prod-list-db.component';


const routes: Routes = [
  {
    path:'',
    component: Bootsnip1Component
  },
  {
    path: 'about',
    component: AboutComponent

  },
  {
    path:'shop',
    component:  CategoryComponent
  },
  {
    path:'list/:id',
    component: ProdviewComponent
  },
  {
    path:'list',
    component: ProdListComponent
  },
  {
    path:'product/create',
    component: ProdCreateComponent
  },
  {
    path: 'product/list',
    component: ProdListDBComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
