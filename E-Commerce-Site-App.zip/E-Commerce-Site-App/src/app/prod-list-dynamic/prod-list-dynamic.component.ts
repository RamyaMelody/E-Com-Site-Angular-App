import { Component, OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-prod-list-dynamic',
  templateUrl: './prod-list-dynamic.component.html',
  styleUrls: ['./prod-list-dynamic.component.css']
})
export class ProdListDynamicComponent implements OnInit {

  @Input() productList;  

  constructor() { }

  ngOnInit(): void {
  }

}
