import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-prod-list',
  templateUrl: './prod-list.component.html',
  styleUrls: ['./prod-list.component.css']
})
export class ProdListComponent implements OnInit {
  
  productArray=[
    {
    id : 1,
    prodName: "Corator",
    prodPrice : "$50",
    setimg2 : true
    },
    {
      id : 2,
      prodName: "Tank Top",
      prodPrice : "$60",
      setimg5 : false
    },
    {
      id : 3,
      prodName: "Polo Shirt",
      prodPrice : "$40",
      setimg4 : true
    }
    
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
