import { Component, OnInit, Input } from '@angular/core';

import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-prodview',
  templateUrl: './prodview.component.html',
  styleUrls: ['./prodview.component.css']
})
export class ProdviewComponent implements OnInit {
  

  item1=
  {
    prodName: "Polo Shirt",
    prodPrice: "80$"
  }
 

  

  constructor(private activatedRoute:ActivatedRoute) { 
    let item = this.activatedRoute.snapshot.params.id;
    console.log(this.activatedRoute.snapshot.params.id);
  
    
  }
  
  ngOnInit(): void {
  }
 

}
